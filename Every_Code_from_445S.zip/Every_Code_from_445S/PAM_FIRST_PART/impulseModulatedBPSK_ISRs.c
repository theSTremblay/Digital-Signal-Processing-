// Welch, Wright, & Morrow, 
// Real-time Digital Signal Processing, 2011

///////////////////////////////////////////////////////////////////////
// Filename: impulseModulatedBPSK_ISRs.c
//
// Synopsis: Interrupt service routine for codec data transmit/receive
//
///////////////////////////////////////////////////////////////////////

#include "DSP_Config.h" 
//#include "coeff2.h"	// load the filter coefficients, B[n] ... extern
//#include "coeff1.h"
#include "coeff.h"
#include <stdlib.h>	// needed to call the rand() function
  
// Data is received as 2 16-bit words (left/right) packed into one
// 32-bit word.  The union allows the data to be accessed as a single 
// entity when transferring to and from the serial port, but still be 
// able to manipulate the left and right channels independently.

#define LEFT  0
#define RIGHT 1
#define N 2
#define M 1

#define input 1

volatile union {
	Uint32 UINT;
	Int16 Channel[2];
} CodecDataIn, CodecDataOut;


/* add any global variables here */
Int32 counter = 0;
Int32 samplesPerSymbol = 20;
Int32 symbol;
Int32 data[2] = {-15000, 15000};
Int32 cosine[4] = {1, 0, -1, 0};
Int32 i;

float x[8];
float y;
float output;

float B1[N+1] = {1, 0, -1};
float A1[N+1] = {1, -1.96004314890818, 0.984414127416097};
float G1[M+1] = {0.0078, 1};

float x1[N+1] = {0, 0, 0};
float y1[N+1] = {0, 0, 0};

float B2[N+1] = {1, 0, -1};
float A2[N+1] = {1, -1.87292545631220, 0.969067417193792};
float G2[M+1] = {0.0155, 1};

float x2[N+1] = {0, 0, 0};
float y2[N+1] = {0, 0, 0};

int SSRG_state = 5;
int flagBit = 0;

int SSRG_update(int *state_ptr, int in){
	// Calculate Newest Bit
	int BitN;
	int BitNMinusEighteen = ((*state_ptr >> 5) & 1);
	int BitNMinusTwentyThree = ((*state_ptr) & 1);
	int interBit = BitNMinusEighteen ^ BitNMinusTwentyThree;
	BitN = interBit ^ in;

	// Shift Right
	*state_ptr = *state_ptr >> 1;
	*state_ptr = *state_ptr | (BitN << 22);
	//Store_state(state_ptr);
	return BitN;
}

float clock_recover(float o){
	// Pre-filter
	int i = 0;

	x1[0] = o*G1[0];
	y1[0] = 0;
	for(i = 0; i < N + 1; i++){
		y1[0] += B1[i]*x1[i];
	}

	for(i = 1; i < N + 1; i++){
		y1[0] -= A1[i]*y1[i];
	}

	for(i = N; i > 0; i--){
		y1[i] = y1[i-1];
		x1[i] = x1[i-1];
	}

	float preFiltOutput = y1[0]*G1[1];

	// Square
	preFiltOutput = preFiltOutput * preFiltOutput;

	x2[0] = preFiltOutput*G2[0];
	// Post-filter
	int j = 0;
	y2[0] = 0;
	for(j = 0; j < N + 1; j++){
		y2[0] += B2[j]*x2[j];
	}

	for(j = 1; j < N + 1; j++){
		y2[0] -= A2[j]*y2[j];
	}

	for(j = N; j > 0; j--){
		y2[j] = y2[j-1];
		x2[j] = x2[j-1];
	}

	float postFiltOutput = y2[0]*G2[1];
	return postFiltOutput;
}



interrupt void Codec_ISR()
///////////////////////////////////////////////////////////////////////
// Purpose:   Codec interface interrupt service routine  
//
// Input:     None
//
// Returns:   Nothing
//
// Calls:     CheckForOverrun, ReadCodecData, WriteCodecData
//
// Notes:     None
///////////////////////////////////////////////////////////////////////
{                    
	/* add any local variables here */

 	if(CheckForOverrun())					// overrun error occurred (i.e. halted DSP)
		return;								// so serial port is reset to recover

  	CodecDataIn.UINT = ReadCodecData();		// get input data samples
	
	/* add your code starting here */

	// I added my IM BPSK routine here
    if (counter == 0) {
    	symbol = SSRG_update(&SSRG_state, input) & 1; // a faster version of rand() % 2

    	//flagBit = flagBit ^ 1;
    	//symbol = flagBit & 1;
		x[0] = data[symbol]; // read the table
	}

    // perform impulse modulation based on the FIR filter, B[N] 
    y  = 0;

    for (i = 0; i < 8; i++) {
		y +=  x[i]*B[counter + 20*i];	// perform the dot-product
	}
    
    if (counter == (samplesPerSymbol - 1)) {
    	counter = -1; 

		/* shift x[] in preparation for the next symbol */
 		for (i = 7; i > 0; i--) {
			x[i] = x[i - 1];          // setup x[] for the next input
		}
   	}

   	counter++;

	output = y;
	

	CodecDataOut.Channel[RIGHT]  = output; // setup the LEFT  value
	CodecDataOut.Channel[LEFT] = clock_recover(output/15000)*28000; // setup the RIGHT value
	// end of my IM BPSK routine

	/* end your code here */

	WriteCodecData(CodecDataOut.UINT);		// send output data to  port
}
