/* coeff.h                                  */
/* DF2 filter coefficients                  */
/* exported from MATLAB using fir_dump2c.m  */


#define N 30

extern float B[];

