// Welch, Wright, & Morrow, 
// Real-time Digital Signal Processing, 2011

///////////////////////////////////////////////////////////////////////
// Filename: ISRs.c
//
// Synopsis: Interrupt service routine for codec data transmit/receive
//
///////////////////////////////////////////////////////////////////////

#include "DSP_Config.h" 
  
// Data is received as 2 16-bit words (left/right) packed into one
// 32-bit word.  The union allows the data to be accessed as a single 
// entity when transferring to and from the serial port, but still be 
// able to manipulate the left and right channels independently.

#define LEFT  0
#define RIGHT 1

volatile union {
	Uint32 UINT;
	Int16 Channel[2];
} CodecDataIn, CodecDataOut;


/* add any global variables here */

#define LFSR_LENGTH			16
#define LFSR_BIT_MASK		((1 << LFSR_LENGTH) - 1)
#define LFSR_XOR_MASK		(((1 << 16) | (1 << 14) | (1 << 13) | (1 << 11)) >> 1)
#define LFSR_SEED_VALUE		3

// reduce LFSR update rate to Fs/DIVIDE_BY_N
#define DIVIDE_BY_N			10
#define A 32000
#define input 1

Uint32 LSFR_reg = LFSR_SEED_VALUE;

int SSRG_state = 21;
int value_100_states[100];

int DS_state = 21;
int DD_state = 21;

void Store_state(int *state_ptr){
	static int first_100_iterations = 0;
	if(first_100_iterations < 100){
		value_100_states[first_100_iterations] = *state_ptr;
		first_100_iterations += 1;
		if(first_100_iterations == 100){
			int i;
			for(i = 0; i < 100; i++){
				printf("%d\n", value_100_states[i]);
			}
		}
	}
}

int SSRG_update(int *state_ptr, int in){
	// Calculate Newest Bit
	int BitN;
	int BitNMinusTwo = ((*state_ptr >> 3) & 1);
	int BitNMinusFive = ((*state_ptr) & 1);
	int interBit = BitNMinusTwo ^ BitNMinusFive;
	BitN = interBit ^ in;

	// Shift Right
	*state_ptr = *state_ptr >> 1;
	*state_ptr = *state_ptr | (BitN << 4);
	//Store_state(state_ptr);
	return BitN;
}

int DD_update(int *state_ptr, int in){
	// Calculate Newest Bit
	int BitN;
	int BitNMinusTwo = ((*state_ptr >> 3) & 1);
	int BitNMinusFive = ((*state_ptr) & 1);
	int interBit = BitNMinusTwo ^ BitNMinusFive;
	BitN = interBit ^ in;

	// Shift Right
	*state_ptr = *state_ptr >> 1;
	*state_ptr = *state_ptr | (in << 4);
	Store_state(state_ptr);
	return BitN;
}

interrupt void Codec_ISR()
///////////////////////////////////////////////////////////////////////
// Purpose:   Codec interface interrupt service routine  
//
// Input:     None
//
// Returns:   Nothing
//
// Calls:     CheckForOverrun, ReadCodecData, WriteCodecData
//
// Notes:     None
///////////////////////////////////////////////////////////////////////
{                    
	/* add any local variables here */
	float xLeft, xRight, yLeft, yRight;


 	if(CheckForOverrun())					// overrun error occurred (i.e. halted DSP)
		return;								// so serial port is reset to recover

  	CodecDataIn.UINT = ReadCodecData();		// get input data samples
	
	/* add your code starting here */

	// this example simply copies sample data from in to out
	//xLeft  = CodecDataIn.Channel[ LEFT];
	//xRight = CodecDataIn.Channel[ RIGHT];

	//yLeft  = xLeft;
	//yRight = xRight;

	//CodecDataOut.Channel[ LEFT] = A*((SSRG_state >> 4) & 1);
	//SSRG_update(&SSRG_state, 0);
	//CodecDataOut.Channel[RIGHT] = yRight;

  	int DS_output = SSRG_update(&DS_state, input);
  	int output = DD_update(&DD_state, DS_output);

  	CodecDataOut.Channel[ LEFT] = A*(input);
  	CodecDataOut.Channel[RIGHT] = A*((DD_state >> 4) & 1);

	/* end your code here */

	WriteCodecData(CodecDataOut.UINT);		// send output data to  port
}

